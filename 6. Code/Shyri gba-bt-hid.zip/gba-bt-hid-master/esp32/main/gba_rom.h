//
// Created by Shyri on 2019-10-30.
//

#ifndef GBA_BT_HID_FW_ESP32_GBA_ROM_H
#define GBA_BT_HID_FW_ESP32_GBA_ROM_H

#include <stdint.h>

const uint8_t rom[58544];

#endif //GBA_BT_HID_FW_ESP32_GBA_ROM_H
