//
// Created by Shyri on 2019-10-22.
//
#include "multiboot.h"
#include "hc05.h"

// ===============================
// LED STATUS (ESP32 GPIO2)
// ===============================
// NOTE: This section is optional and can be enabled
// to provide visual Bluetooth connection status.
// ===============================
#include "driver/gpio.h"

#define LED_GPIO GPIO_NUM_2

static void init_led(void)
{
    // Configure GPIO2 as output
    gpio_pad_select_gpio(LED_GPIO);
    gpio_set_direction(LED_GPIO, GPIO_MODE_OUTPUT);

    // Default state: OFF
    gpio_set_level(LED_GPIO, 0);
}

// ===============================

#define __BTSTACK_FILE__ "main.c"

int btstack_main(int argc, const char *argv[]);

int btstack_main(int argc, const char *argv[]) {

    // Initialize LED (STATUS INDICATOR)
    // ---------------------------------
    // LED behavior (future integration):
    // - Blinking = waiting for Bluetooth connection
    // - Solid ON = Bluetooth connected
    // ---------------------------------
    init_led();

    multiboot();
    initHC05();

    return 0;
}